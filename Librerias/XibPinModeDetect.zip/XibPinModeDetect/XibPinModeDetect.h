#ifndef XibPinModeDetect_h
#define XibPinModeDetect_h
#include <Arduino.h>

uint8_t XibGetPinMode(uint8_t pin);


#endif