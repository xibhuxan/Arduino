
# XibPinModeDetect Library

This library allows you to check the current state of a pin. It could be useful when you are changing it and need to check the state.

The possible states of a pin and the number returned are:
- INPUT = 0
- INPUT_PULLUP = 1
- OUTPUT = 2

You can check how it works in the given example.