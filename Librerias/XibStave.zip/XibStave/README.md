
Created by Xibhu - Carlos MR - https://github.com/xibhu  
Made in Canary islands, Spain

# XibStave library

This library allows you to use many staves independently, one stave per speaker. To create a stave, use the variables on "Durations.h", "Pitches.h" and follows the example codes.

The most important thing is to modify the var "TOTAL_SPEAKERS" from the file "XibStave.h". Use the number of speakers you want to use.