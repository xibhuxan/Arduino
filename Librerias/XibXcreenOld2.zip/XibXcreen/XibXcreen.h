#ifndef XibXcreen_h
#define XibXcreen_h

#include <Adafruit_GFX.h>
#include <Adafruit_TFTLCD.h>
#include <TouchScreen.h>
class XibXcreen
{
public:
    static TouchScreen ts;
    static Adafruit_TFTLCD tft;
    static TSPoint tsp;
};

#endif
