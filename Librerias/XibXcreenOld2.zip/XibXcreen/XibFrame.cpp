#include <XibFrame.h>

void XibFrame::addComponent(XibComponent &component)
{
    XibComponent *myC = &component;
    components.Append(myC);
    Attach(*myC);
}

void XibFrame::draw()
{
    XibXcreen::tft.fillScreen(color);
}

void XibFrame::drawComponents()
{

    for (int i = 0; i <= maxLayers; i++)
    {
        for (int j = 0; j < components.getLength(); j++)
        {
            XibComponent *comp = components.getElement(j);
            if (comp->getLayer() == i)
            {
                comp->DrawMySelf();
            }
        }
    }
}
void XibFrame::setColor(int color)
{
    this->color = color;
}
void XibFrame::Update(Subject &theChangedSubject)
{
    int x = XibXcreen::tsp.x;
    int y = XibXcreen::tsp.y;
    for (int i = maxLayers; i <= 0; i--)
    {
        XibComponent *comp = components.getElement(i);
        if (comp->CoorInsideMe(x, y))
        {
            Notify(comp);
            break;
        }
    }
}

void XibFrame::setMaxLayers(int numLayers)
{
    maxLayers = numLayers;
}