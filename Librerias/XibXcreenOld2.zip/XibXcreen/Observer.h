//https://riptutorial.com/es/cplusplus/example/24695/patron-observador
#ifndef Observer_h
#define Observer_h

class Subject;

class Observer
{
public:
    virtual ~Observer() = default;
    virtual void Update(Subject &) = 0;
};

#endif
