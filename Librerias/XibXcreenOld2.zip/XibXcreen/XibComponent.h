#ifndef XibComponent_h
#define XibComponent_h
#include <Subject.h>
#include <XibXcreen.h>

class XibComponent : public Observer, public Subject
{
private:
    int x;
    int y;
    int layer;

public:

    virtual void DrawMySelf();
    void Update(Subject &theChangedSubject);
    virtual bool CoorInsideMe(int x, int y);
    void setX(int x);
    void setY(int y);
    int getX();
    int getY();
    void setLayer(int layer);
    int getLayer();
};

/*DIBUJADOS FIJOS*/
class XibFixed : public XibComponent
{
private:
public:
};

/*Boton*/
class XibBoton : public XibFixed
{
private:
    int secondX;
    int secondY;

public:
    void setCoor(int x, int y, int secondX, int secondY);
    void DrawMySelf() override;
    bool CoorInsideMe(int x, int y) override;
};

/*DIBUJADOS MOVIBLES*/
class XibMovible : public XibComponent
{
private:
    int oldX;
    int oldY;

public:
};

/*DragAndDrop*/
class XibDragAndDrop : public XibMovible
{
private:
public:
    void DrawMySelf();
};

#endif