#include <XibComponent.h>

void XibComponent::Update(Subject &theChangedSubject)
{
}
bool XibComponent::CoorInsideMe(int x, int y)
{
}
void XibComponent::DrawMySelf()
{
}
void XibComponent::setX(int x)
{
    this->x = x;
}
void XibComponent::setY(int y)
{
    this->y = y;
}
int XibComponent::getX()
{
    return x;
}
int XibComponent::getY()
{
    return y;
}
void XibComponent::setLayer(int layer)
{
    this->layer = layer;
}
int XibComponent::getLayer()
{
    return layer;
}

/*Boton*/
void XibBoton::setCoor(int x, int y, int secondX, int secondY)
{
    setX(x);
    setY(y);
    this->secondX = secondX;
    this->secondY = secondY;
}
void XibBoton::DrawMySelf()
{
    XibXcreen::tft.fillRect(getX(), getY(), secondX, secondY, 0x011F);
}
bool XibBoton::CoorInsideMe(int x, int y)
{
    //TODO

    return (x > getX() && x < getX()+secondX) && (y > getY() && y < getY()+secondY);
}

/*DragAndDrop*/

void XibDragAndDrop::DrawMySelf()
{
}