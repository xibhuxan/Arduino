#ifndef XibFrame_h
#define XibFrame_h

#include <LinkedList.h>
#include <XibComponent.h>
#include <XibXcreen.h>
#include <Subject.h>

class XibFrame : public Observer, public Subject
{
private:
    LinkedList<XibComponent *> components;
    int color;
    int maxLayers;

public:
    void addComponent(XibComponent &component);
    void draw();
    void drawComponents();
    void setColor(int color);
    void setMaxLayers(int numLayers);
    void Update(Subject &theChangedSubject);
};
#endif