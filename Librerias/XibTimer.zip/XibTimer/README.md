
Created by Xibhu - Carlos MR - https://github.com/xibhu  
Made in Canary islands, Spain
# XibTimer Library

This library is a timer, allows you to execute code every "X" time. You can enable or disable it. Also you can change the time if needed.

You SHOULD use it to avoid the function "delay()" and start to make code with a bit of "multithread" (not real, but in arduino seems that).

You can see how to use this library in the folder `Example`.

There are four examples:

- Using bool, to put your timer inside an IF or similar.
- Using function without parameters, to execute it directly.
- Using function with parameters, to give parameters to the function and then use it.
- Using lambda, to put code inside.