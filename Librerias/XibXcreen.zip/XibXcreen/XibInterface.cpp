
#include <Arduino.h>
#include <XibInterface.h>

void XibInterface::refreshTouchValues()
{
    refreshTouchValues(1);
}
void XibInterface::refreshTouchValues(int tiempo)
{

    if (millis() - tiempo > tiempoContaje)
    {
        tiempoContaje = millis();
        XibXcreen::tsp = XibXcreen::ts.getPoint();
        pinMode(XM, OUTPUT);
        pinMode(YP, OUTPUT);
        XibXcreen::tsp.x = map(XibXcreen::tsp.x, TS_MINX, TS_MAXX, 0, 320);
        XibXcreen::tsp.y = map(XibXcreen::tsp.y, TS_MINY, TS_MAXY, 0, 240);
        rellenarArray(XibXcreen::tsp.z);
    }
}

void XibInterface::rellenarArray(int valor)
{
    valoresPrecision[indicePrecision] = valor;

    indicePrecision++;
    if (indicePrecision >= PRECISION_AMOUNT)
    {
        indicePrecision = 0;
    }
}

bool XibInterface::isScreenTouched()
{

    bool pisada = false;
    for (int i = 0; i < PRECISION_AMOUNT; i++)
    {
        if (valoresPrecision[i] != 0)
        {
            pisada = true;
            break;
        }
    }

    return pisada && XibXcreen::tsp.z > MINPRESSURE;
}

void XibInterface::drawFrame(int x)
{

    if (currentFrameNumber != x)
    {
        currentFrame = frames.getElement(x);
        currentFrame->draw();
        currentFrameNumber = x;
    }
    currentFrame->drawComponents();
}

void XibInterface::addFrame(XibFrame &f)
{
    frames.Append(&f);
}

XibFrame *XibInterface::getFrame(int x)
{
    return frames.getElement(x);
}

//Funcion original, no tocar
/*
TSPoint waitTouch()
{
    TSPoint p;
    do
    {
        p = ts.getPoint();
        pinMode(XM, OUTPUT);
        pinMode(YP, OUTPUT);
    } while ((p.z < MINPRESSURE) || (p.z > MAXPRESSURE));
    p.x = map(p.x, TS_MINX, TS_MAXX, 0, 320);
    p.y = map(p.y, TS_MINY, TS_MAXY, 0, 240);
    return p;
}
*/