#ifndef XibFrame_h
#define XibFrame_h

#include <LinkedList.h>
#include <XibComponent.h>
#include <XibXcreen.h>

class XibFrame
{
private:
    
    LinkedList<XibComponent> components;

public:
int color;
    void addComponent(XibComponent c);
    void draw();
    void drawComponents();
    void setColor(int c);
};
#endif