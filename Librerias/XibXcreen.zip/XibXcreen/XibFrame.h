#ifndef XibFrame_h
#define XibFrame_h

#include <LinkedList.h>
#include <XibComponent.h>
#include <XibXcreen.h>
#include <Subject.h>

class XibFrame : public Observer, public Subject
{
private:
    LinkedList<XibComponent *> components;
    int color;
    int maxLayers;
    String name;

public:
    void addComponent(XibComponent &component);
    void draw();
    void drawComponents();
    void setColor(int color);
    int getColor();
    void setName(String name);
    String getName();
    void setMaxLayers(int numLayers);
    int getMaxLayers();
    void Update(Subject &theChangedSubject) override;
};
#endif