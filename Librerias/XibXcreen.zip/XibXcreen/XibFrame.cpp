#include <XibFrame.h>

void XibFrame::addComponent(XibComponent &component)
{
    XibComponent *myC = &component;
    components.Append(myC);
    Attach(*myC);
}

void XibFrame::draw()
{
    XibXcreen::tft.fillScreen(color);
}

void XibFrame::drawComponents()
{

    for (int i = 0; i <= maxLayers; i++)
    {
        
        for (int j = 0; j < components.getLength(); j++)
        {
            XibComponent *comp = components.getElement(j);
            if (comp->getLayer() == i)
            {
                comp->DrawMySelf();
            }
        }
    }
}

void XibFrame::setColor(int color)
{
    this->color = color;
}
int XibFrame::getColor()
{
    return color;
}

void XibFrame::setName(String name)
{
    this->name = name;
}
String XibFrame::getName()
{
    return name;
}

void XibFrame::setMaxLayers(int numLayers)
{
    maxLayers = numLayers;
}
int XibFrame::getMaxLayers()
{
    return maxLayers;
}

void XibFrame::Update(Subject &theChangedSubject)
{
    int x = XibXcreen::tsp.x;
    int y = XibXcreen::tsp.y;
    //XibXcreen::tft.drawCircle(0,0,20,BLACK);
    bool compMaxLayer = false;
    
    for (int i = maxLayers; i >= 0 && !compMaxLayer; i--)
    {
        for (int j = 0; j < components.getLength() && !compMaxLayer; j++)
        {
            XibComponent *comp = components.getElement(j);
            if (comp->CoorInsideMe(x, y) && comp->getLayer() == i)
            {
                Notify(comp);
                compMaxLayer = true;
            }
        }
    }
}