#include <XibFrame.h>

void XibFrame::addComponent(XibComponent c)
{
    components.Append(c);
}

void XibFrame::draw()
{
    XibXcreen::tft.fillScreen(color);
}

void XibFrame::drawComponents()
{
}
void XibFrame::setColor(int c)
{
    color = c;
}