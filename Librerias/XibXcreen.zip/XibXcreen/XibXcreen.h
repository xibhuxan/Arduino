#ifndef XibXcreen_h
#define XibXcreen_h

#include <Adafruit_GFX.h>
#include <Adafruit_TFTLCD.h>
#include <TouchScreen.h>
#include <XibXcreenValues.h>
class XibXcreen
{
public:
    static TouchScreen ts;
    static Adafruit_TFTLCD tft;
    static TSPoint tsp;
    static int xPercent;
    static int yPercent;
    static TSPoint percentToPixel(int xPercent, int yPercent)
    {
        TSPoint point;
        switch (XibXcreen::tft.getRotation())
        {
        case 0:
            point.x = map(xPercent, 0, 100, 0, SHORT_SIDE);
            point.y = map(yPercent, 0, 100, 0, LONG_SIDE);
            break;

        case 1:
            point.x = map(xPercent, 0, 100, 0, LONG_SIDE);
            point.y = map(yPercent, 0, 100, 0, SHORT_SIDE);
            break;

        case 2:
            point.x = map(xPercent, 0, 100, 0, SHORT_SIDE);
            point.y = map(yPercent, 0, 100, 0, LONG_SIDE);
            break;

        case 3:
            point.x = map(xPercent, 0, 100, 0, LONG_SIDE);
            point.y = map(yPercent, 0, 100, 0, SHORT_SIDE);
            break;
        }
        return point;
    }
};

#endif
