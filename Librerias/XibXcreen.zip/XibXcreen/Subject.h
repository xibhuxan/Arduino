#ifndef Subject_h
#define Subject_h
#include <LinkedList.h>
#include <Observer.h>

class Subject
{
public:
    virtual ~Subject() = default;
    void Attach(Observer &o) { observers.Append(&o); }
    void Detach(Observer &o);

    void NotifyAll();
    void Notify(Observer *o);
    

private:
    LinkedList<Observer *> observers;
};

#endif
