#ifndef XibComponent_h
#define XibComponent_h

class XibComponent
{
private:
    int x;
    int y;
    int layer;

public:
    void drawMySelf();
};

/*DIBUJADOS FIJOS*/
class XibFijo : public XibComponent
{
private:
public:
    XibFijo();
    ~XibFijo();
};

/*Boton*/
class XibBoton : public XibFijo
{
private:
    int secondX;
    int secondY;

public:
    XibBoton(int x, int y, int secondX, int secondY);
    ~XibBoton();
    void drawMySelf();
};

/*DIBUJADOS MOVIBLES*/
class XibMovible : public XibComponent
{
private:
    int oldX;
    int oldY;

public:
    XibMovible();
    ~XibMovible();
};

/*DragAndDrop*/
class XibDragAndDrop : public XibMovible
{
private:
public:
    XibDragAndDrop(int x, int y);
    ~XibDragAndDrop();
    void drawMySelf();
};

#endif