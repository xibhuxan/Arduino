#ifndef XibComponent_h
#define XibComponent_h
#include <Subject.h>
#include <XibXcreen.h>

class XibComponent : public Observer, public Subject
{
private:
    int x;
    int y;
    int layer;
    

public:

    virtual void DrawMySelf();
    virtual void Update(Subject &theChangedSubject);
    virtual bool CoorInsideMe(int x, int y);
    void setX(int x);
    void setY(int y);
    int getX();
    int getY();
    void setLayer(int layer);
    int getLayer();
};

/*DIBUJADOS FIJOS*/
class XibFixed : public XibComponent
{
private:
public:
};
/*DIBUJADOS MOVIBLES*/
class XibMovable : public XibComponent
{
private:
    int oldX;
    int oldY;

public:
};




/*Boton*/
class XibButton : public XibFixed
{
private:
    int width;
    int height;
    int color;

public:
    void setColor(int color);
    int getColor();
    void setCoor(int x, int y, int secondX, int secondY);
    void setCoorPercent(int xPercent, int yPercent, int secondXpercent, int secondYpercent);
    void DrawMySelf() override;
    bool CoorInsideMe(int x, int y) override;
    void Update(Subject&) override;
};


/*DragAndDrop*/
class XibDragAndDrop : public XibMovable
{
private:
public:
    void DrawMySelf();
};

#endif