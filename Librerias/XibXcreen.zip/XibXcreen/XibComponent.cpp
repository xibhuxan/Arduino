#include <XibComponent.h>

void XibComponent::Update(Subject &theChangedSubject)
{
}
bool XibComponent::CoorInsideMe(int x, int y)
{
}
void XibComponent::DrawMySelf()
{
}
void XibComponent::setX(int x)
{
    this->x = x;
}
void XibComponent::setY(int y)
{
    this->y = y;
}
int XibComponent::getX()
{
    return x;
}
int XibComponent::getY()
{
    return y;
}
void XibComponent::setLayer(int layer)
{
    this->layer = layer;
}
int XibComponent::getLayer()
{
    return layer;
}

/*Boton*/
void XibButton::setColor(int color){
    this->color = color;
}
int XibButton::getColor(){
    return color;
}
void XibButton::setCoor(int x, int y, int width, int height)
{
    setX(x);
    setY(y);
    this->width = width;
    this->height = height;
}
void XibButton::setCoorPercent(int x1, int x2, int y1, int y2)
{
    TSPoint first, second;
    first = XibXcreen::percentToPixel(x1, y1);
    second = XibXcreen::percentToPixel(x2, y2);
    setX(first.x);
    setY(first.y);
    this->width = abs(first.x - second.x);
    this->height = abs(first.y - second.y);
}
void XibButton::DrawMySelf()
{
    XibXcreen::tft.fillRect(getX(), getY(), width, height, color);
}
bool XibButton::CoorInsideMe(int x, int y)
{
    return (x > getX() && x < getX() + width) && (y > getY() && y < getY() + height);
}
void XibButton::Update(Subject &)
{   
    NotifyAll();
}

/*DragAndDrop*/

void XibDragAndDrop::DrawMySelf()
{
}