#include <XibComponent.h>

/*Boton*/
void XibBoton(int x, int y, int secondX, int secondY)
{
}
void XibBoton::drawMySelf()
{
}

/*DragAndDrop*/
void XibDragAndDrop(int x, int y)
{
}
void XibDragAndDrop::drawMySelf()
{
}